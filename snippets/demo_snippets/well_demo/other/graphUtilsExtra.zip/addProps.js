const edgeParamsMapping = {   
    "res_watercut_percent": "res_watercut_percent",// Обводненность,TRUE
    "res_liquid_density_kg_m3": "res_liquid_density_kg_m3",// Плотность жидкости,
    "res_pump_power_watt": "res_pump_power_watt",// Мощность насоса,TRUE
    "X_kg_sec": "res_mass_flow_kg_sec",// Массовый поток,
    "velocity_m_sec": "res_velocity_m_sec"// Скорость потока,TRUE
};
// const defExpr;

const addProps = {
    "res_watercut_percent": "//res_watercut_percent\n' '",
    "res_liquid_density_kg_m3": "//res_liquid_density_kg_m3\n' '",
    "res_pump_power_watt": "//res_pump_power_watt\n' '",
    "X_kg_sec": "//res_mass_flow_kg_sec\n' '",
    "velocity_m_sec": "//res_velocity_m_sec\n' '"
};
// creaate new props and fill annotation
liveDashPanelWhatIf.masterGraph.nodes.toArray().filter(
    node => {
        if (node.tag.properties.object_type in node.tag.properties) {
            return node.tag.properties.object_type.value === "pipe"
        } else {
            return false
        }
        
    }
).map(node => {
    Object.entries(addProps).map(([p, info]) => {
        node.tag.properties[p] = defExpr;
        node.tag.properties[p].expression = info;
    })
})